package com.coach.cip.common.dto;

import java.io.Serializable;

public class UserMetricVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -948469221055723314L;

}

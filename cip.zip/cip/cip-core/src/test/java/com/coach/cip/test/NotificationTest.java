package com.coach.cip.test;

import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.coach.cip.services.NotificationService;

public class NotificationTest {

	
	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("ApplicationContext-service.xml");
	
	
	@Test
	public void testNotification() {
		NotificationService notificationService = (NotificationService) context.getBean("notificationService");
		System.out.println("Insied the Notification====>");
		notificationService.getAllNotifications();
	}
}

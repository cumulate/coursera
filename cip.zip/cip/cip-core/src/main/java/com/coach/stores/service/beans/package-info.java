
/**
 * @author GalaxE.
 */

@javax.xml.bind.annotation.XmlSchema(namespace = "http://coach.com/esb/storewebservice/v1.0")
package com.coach.stores.service.beans;

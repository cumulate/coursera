
@javax.xml.bind.annotation.XmlSchema(namespace = "http://coach.com/esb/employeeWebService/v1.0")
package com.coach.employees.service.beans;
